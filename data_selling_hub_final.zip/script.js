function payUPI() {
  alert('Opening UPI App...');
  window.location.href = 'upi://pay?pa=6005099281@mbk&pn=DataSellingHub&am=59&cu=INR';
}
function submitUTR() {
  let utr = prompt('Enter your UTR Number:');
  if (utr) alert('UTR submitted: ' + utr + '\nPayment will be verified soon.');
}
function refundRequest() {
  let reason = prompt('Enter reason for refund:');
  if (reason) alert('Refund request submitted. Reason: ' + reason);
}
function getApp() {
  alert('Payment not received yet! Please complete the payment to get the app.');
}